#ifndef crypto_int32_H
#define crypto_int32_H

#include <stdint.h>

typedef int32_t crypto_int32;

#endif
